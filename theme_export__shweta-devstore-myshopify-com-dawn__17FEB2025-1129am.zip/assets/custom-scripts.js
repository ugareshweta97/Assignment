$(document).ready(function(){
  setTimeout(function() {
    $('.results-slider').slick({
      infinite: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      dots: false,
      arrows: true,
      autoplay: false,
      prevArrow:'<button aria-label="prev" class="slick-prev slick-arrow"><svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none"><path d="M6 12H18M6 12L11 7M6 12L11 17" stroke="#000000" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"/></svg></button>',
      nextArrow:'<button aria-label="next" class="slick-next slick-arrow"><svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none"><path d="M6 12H18M18 12L13 7M18 12L13 17" stroke="#000000" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"/></svg></button>',
      responsive: [
        {
          breakpoint: 750,
          settings: {
            arrows: false
          }
        }
      ]
    });
  
    $('.article-slider').slick({
      infinite: true,
      slidesToShow: 3,
      slidesToScroll: 1,
      dots: false,
      arrows: true,
      autoplay: false,
      prevArrow:'<button aria-label="prev" class="slick-prev slick-arrow"><svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none"><path d="M6 12H18M6 12L11 7M6 12L11 17" stroke="#000000" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"/></svg></button>',
      nextArrow:'<button aria-label="next" class="slick-next slick-arrow"><svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none"><path d="M6 12H18M18 12L13 7M18 12L13 17" stroke="#000000" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"/></svg></button>',  
      responsive: [
        {
          breakpoint: 750,
          settings: {
            arrows: false,
            slidesToShow: 1,
            slidesToScroll: 1
          }
        }
      ]
    });
  
    $('.dermatologist-slider').on('init reInit afterChange', function(event, slick, currentSlide){
      let currentIndex = currentSlide || 0;
      $('.doctor-avatar').removeClass('active');
      $('.doctor-avatar[data-index="' + currentIndex + '"]').addClass('active');
    });
    
    $('.dermatologist-slider').slick({
      infinite: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      dots: false,
      arrows: true,
      prevArrow:'<button aria-label="prev" class="slick-prev slick-arrow"><svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none"><path d="M6 12H18M6 12L11 7M6 12L11 17" stroke="#000000" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"/></svg></button>',
      nextArrow:'<button aria-label="next" class="slick-next slick-arrow"><svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none"><path d="M6 12H18M18 12L13 7M18 12L13 17" stroke="#000000" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"/></svg></button>',
      responsive: [
        {
          breakpoint: 750,
          settings: {
            arrows: false
          }
        }
      ]
    });
  
    $('.gallery-grid').slick({
      infinite: true,
      slidesToShow: 5,
      slidesToScroll: 1,
      dots: false,
      arrows: false,
      autoplay: false,
      centerMode: true,
      centerPadding: '60px',
      responsive: [
        {
          breakpoint: 750,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1
          }
        }
      ]
    });
  }, 1000);
});           
  
